import java.util.Scanner;
import java.lang.Math.*;
public class Main {
        public static void main(String[] args){
//recolher os numeros dados do usuario
            Scanner scanner = new Scanner(System.in);
            System.out.println("digite o valor de a,b,c");
            double a = 0 , b = 0, c =0;
            for (int i = 0 ;i<3 ; i++){
                if (i == 0) {
                    a = scanner.nextDouble();
                }if (i == 1) {
                    b = scanner.nextDouble();
                }if (i == 2){
                    c = scanner.nextDouble();
                }
            }

            scanner.close();
//resolver baskara para saber delta
            double delt = (b*b)-(4*a*c);
            System.out.println("valor de delta é:"+ delt);
//saber as raizes
            double raiz1 = (-b + Math.sqrt(delt)) / (2 * a);
            double raiz2 = (-b - Math.sqrt(delt)) / (2 * a);

            System.out.println("Raiz 1 = " + raiz1);
            System.out.println("Raiz 2 = " + raiz2);

        }
}